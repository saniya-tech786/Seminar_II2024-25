<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $conn = new mysqli("localhost", "root", "", "spicekart");
  if ($conn->connect_error) die("DB Error");

  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

  $check = $conn->query("SELECT * FROM users WHERE email='$email'");
  if ($check->num_rows > 0) {
    echo "<script>alert('Email already exists!'); window.location.href='register.php';</script>";
    exit();
  }

  $sql = "INSERT INTO users (full_name, email, password) VALUES ('$name', '$email', '$password')";
  if ($conn->query($sql)) {
    echo "<script>alert('Registration successful!'); window.location.href='login.php';</script>";
  } else {
    echo "<script>alert('Something went wrong.');</script>";
  }
  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register - SpiceKart</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="register.css">
</head>
<body>
  <header class="navbar">
    <div class="logo">SpiceKart 🌶️</div>
    <nav class="nav-links">
      <a href="index.html">Home</a>
      <a href="product.html">Product</a>
      <a href="about.html">About</a>
      <a href="contact.html">Contact</a>
      <a href="login.php">Login</a>
      <a href="register.php">Register</a>
    </nav>
  </header>

  <section class="register-section">
    <div class="register-container">
      <h1>Create Your SpiceKart Account</h1>
      <form class="register-form" method="POST">
        <label>Full Name</label>
        <input type="text" name="name" placeholder="Enter your full name" required />

        <label>Email</label>
        <input type="email" name="email" placeholder="Enter your email" required />

        <label>Password</label>
        <input type="password" name="password" placeholder="Create a password" required />

        <button type="submit" class="btn">Register</button>
        <p class="extra">Already have an account? <a href="login.php">Login here</a>.</p>
      </form>
    </div>
  </section>
</body>
</html>
