// 🛒 Add product to cart
function addToCart(name, price, image) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  const existing = cart.find(item => item.name === name);

  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ name, price, image, quantity: 1 });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  alert(`${name} added to cart!`);
}

// 🧾 Load cart items
function loadCartItems() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const container = document.querySelector('.cart-container');
  const totalEl = document.querySelector('.cart-summary h2');

  container.innerHTML = '';

  let total = 0;

  if (cart.length === 0) {
    container.innerHTML = '<p style="text-align:center;">Your cart is empty 🛒</p>';
    totalEl.textContent = `Total: ₹0`;
    return;
  }

  cart.forEach((item, index) => {
    const subtotal = item.price * item.quantity;
    total += subtotal;

    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <div class="cart-details">
        <h3>${item.name}</h3>
        <p>₹${item.price} × ${item.quantity} = ₹${subtotal}</p>
        <input type="number" min="1" value="${item.quantity}" onchange="updateQuantity(${index}, this.value)">
      </div>
      <button class="remove-btn" onclick="removeFromCart(${index})">Remove</button>
    `;
    container.appendChild(div);
  });

  totalEl.textContent = `Total: ₹${total}`;
}

// ✏️ Update quantity
function updateQuantity(index, newQty) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart[index].quantity = parseInt(newQty);
  localStorage.setItem('cart', JSON.stringify(cart));
  loadCartItems();
}

// ❌ Remove item from cart
function removeFromCart(index) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  loadCartItems();
}

// ▶️ Run on cart page only
document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('.cart-container')) {
    loadCartItems();
  }
});
