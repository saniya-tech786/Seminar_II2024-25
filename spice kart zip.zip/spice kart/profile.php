<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id=$user_id";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Profile - SpiceKart</title>
  <style>
    body { font-family: Arial; background: #fff8f0; padding: 20px; }
    .profile-container { max-width: 600px; margin: auto; background: white; padding: 20px; border-radius: 10px; }
    .profile-container h2 { color: #8B0000; text-align: center; }
    .info { line-height: 1.8; }
    .info strong { width: 100px; display: inline-block; }
  </style>
</head>
<body>

<div class="profile-container">
  <h2>Welcome, <?php echo $user['name']; ?>!</h2>
  <div class="info">
    <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
    <p><strong>Phone:</strong> <?php echo $user['phone']; ?></p>
  </div>
  <a href="logout.php">Logout</a>
</div>

</body>
</html>
