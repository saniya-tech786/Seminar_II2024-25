// script.js
// Load existing cart or start fresh
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// 🛒 Add item to cart
function addToCart(name, price) {
  const existing = cart.find(item => item.name === name);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ name, price, qty: 1 });
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  showToast(`${name} added to cart!`);
  updateCartCount();
}

// 🧮 Update cart item count in navbar
function updateCartCount() {
  const count = cart.reduce((acc, item) => acc + item.qty, 0);
  const badge = document.getElementById("cartCount");
  if (badge) badge.textContent = count;
}

// 🔍 Search filter for products
function searchProducts() {
  const input = document.getElementById("searchBar").value.toLowerCase();
  const cards = document.querySelectorAll(".product-card");

  cards.forEach(card => {
    const name = card.querySelector("h3").textContent.toLowerCase();
    card.style.display = name.includes(input) ? "block" : "none";
  });
}

// 🔽 Sort products by price
function sortProducts(order) {
  const container = document.querySelector(".product-grid");
  const cards = Array.from(container.children);

  cards.sort((a, b) => {
    const priceA = parseInt(a.querySelector("p").textContent.replace(/[^0-9]/g, ""));
    const priceB = parseInt(b.querySelector("p").textContent.replace(/[^0-9]/g, ""));
    return order === "asc" ? priceA - priceB : priceB - priceA;
  });

  cards.forEach(card => container.appendChild(card));
}

// 🔔 Toast notifications instead of alert
function showToast(message) {
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// 🌙 Toggle dark mode
function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
}

// 👀 Save product to preview page
function viewProduct(name, price, image) {
  localStorage.setItem("selectedProduct", JSON.stringify({ name, price, image }));
  window.location.href = "product-detail.html";
}

// 📦 Load preview on product-detail.html
function loadProductDetail() {
  const p = JSON.parse(localStorage.getItem("selectedProduct"));
  if (!p) return;
  const container = document.getElementById("productDetail");
  container.innerHTML = `
    <h1>${p.name}</h1>
    <img src="${p.image}" alt="${p.name}" style="max-width: 300px; border-radius: 8px;">
    <p>Price: ₹${p.price}</p>
    <button onclick="addToCart('${p.name}', ${p.price})">Add to Cart</button>
  `;
}

// 🔃 Run on page load
window.onload = updateCartCount;
// 📌 Add event listeners to trigger dark mode on interaction
window.onload = function () {
  updateCartCount();

  // 🔍 Trigger dark mode when search bar is focused or clicked
  const searchBar = document.getElementById("searchBar");
  if (searchBar) {
    searchBar.addEventListener("focus", toggleDarkMode);
  }

  // 🔽 Trigger dark mode when sort dropdown is clicked
  const sortSelect = document.querySelector("select");
  if (sortSelect) {
    sortSelect.addEventListener("change", toggleDarkMode);
  }
};
